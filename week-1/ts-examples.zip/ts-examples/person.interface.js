"use strict";
/**
 * Title: person.interface.ts
 * Author: Chris Bohnet
 * Date: 12 July 2020
 * Description: Person interface
 */
exports.__esModule = true;
